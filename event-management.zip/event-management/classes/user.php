<?php
require_once 'Database.php';

class User {
    private $db;

    public function __construct() {
        $this->db = new Database();
    }

    public function register($username, $email, $password) {
        $passwordHash = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $this->db->query("INSERT INTO users (username, email, password) VALUES (:username, :email, :password)");
        return $this->db->execute($stmt, [
            'username' => $username,
            'email' => $email,
            'password' => $passwordHash
        ]);
    }

    public function login($username, $password) {
        $stmt = $this->db->query("SELECT * FROM users WHERE username = :username");
        $this->db->execute($stmt, ['username' => $username]);
        $user = $this->db->resultSet($stmt);

        error_log("Debug: After querying user");
        error_log("Debug: User found - " . json_encode($user));

        if ($user) {
            if (password_verify($password, $user[0]['password'])) {
                $_SESSION['user_id'] = $user[0]['id'];
                error_log("Debug: Password verification - success");
                return true;
            } else {
                error_log("Debug: Password verification - failure");
            }
        } else {
            error_log("Debug: User not found.");
        }
        return false;
    }

    public function isLoggedIn() {
        return isset($_SESSION['user_id']);
    }

    public function logout() {
        session_destroy();
    }
}
