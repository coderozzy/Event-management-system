<?php
require_once 'Database.php';

class Event {
    private $db;

    public function __construct() {
        $this->db = new Database();
    }

    public function create($user_id, $name, $description, $event_date, $location) {
        error_log("Debug: Inside create method");
        $stmt = $this->db->query("INSERT INTO events (user_id, name, description, event_date, location) VALUES (:user_id, :name, :description, :event_date, :location)");
        return $this->db->execute($stmt, [
            'user_id' => $user_id,
            'name' => $name,
            'description' => $description,
            'event_date' => $event_date,
            'location' => $location
        ]);
    }

    public function getAllByUser($user_id) {
        error_log("Debug: Inside getAllByUser method");
        $stmt = $this->db->query("SELECT * FROM events WHERE user_id = :user_id");
        $this->db->execute($stmt, ['user_id' => $user_id]);
        return $this->db->resultSet($stmt);
    }

    public function update($id, $name, $description, $event_date, $location) {
        error_log("Debug: Inside update method");
        $stmt = $this->db->query("UPDATE events SET name = :name, description = :description, event_date = :event_date, location = :location WHERE id = :id");
        return $this->db->execute($stmt, [
            'id' => $id,
            'name' => $name,
            'description' => $description,
            'event_date' => $event_date,
            'location' => $location
        ]);
    }

    public function delete($id) {
        error_log("Debug: Inside delete method");
        $stmt = $this->db->query("DELETE FROM events WHERE id = :id");
        return $this->db->execute($stmt, ['id' => $id]);
    }
}
