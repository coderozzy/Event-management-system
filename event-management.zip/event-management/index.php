<?php
require_once 'classes/Session.php';

$session = new Session();
$session->start();

$user_id = $session->get('user_id');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Event Management System</title>
</head>
<body>
<header>
    <h1>Event Management System</h1>
    <nav>
        <a href="index.php">Home</a>
        <?php if ($user_id): ?>
            <a href="events.php">My Events</a>
            <a href="logout.php">Logout</a>
        <?php else: ?>
            <a href="login.php">Login</a>
            <a href="register.php">Register</a>
        <?php endif; ?>
    </nav>
</header>
<main>
    <h2>Welcome to the Event Management System</h2>
    <?php if ($user_id): ?>
        <p>You are logged in as User ID: <?= $user_id ?></p>
    <?php else: ?>
        <p>Please <a href="login.php">login</a> or <a href="register.php">register</a> to manage your events.</p>
    <?php endif; ?>
</main>
<footer>
    <p>&copy; <?= date('Y') ?> Event Management System. All rights reserved.</p>
</footer>
</body>
</html>
