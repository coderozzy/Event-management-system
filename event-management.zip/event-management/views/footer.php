</main>
<footer>
    <p>&copy; Event Management System</p>
</footer>
</body>
</html>
