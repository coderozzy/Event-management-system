<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'classes/Event.php';
require_once 'classes/Session.php';

$session = new Session();
$session->start();

if (!$session->get('user_id')) {
    header('Location: login.php');
    exit;
}

$event = new Event();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['create'])) {
        $name = $_POST['name'] ?? '';
        $description = $_POST['description'] ?? '';
        $event_date = $_POST['event_date'] ?? '';
        $location = $_POST['location'] ?? '';

        error_log("Creating event: Name=$name, Description=$description, Date=$event_date, Location=$location");

        $event->create($session->get('user_id'), $name, $description, $event_date, $location);
    } elseif (isset($_POST['update'])) {
        $id = $_POST['id'] ?? 0;
        $name = $_POST['name'] ?? '';
        $description = $_POST['description'] ?? '';
        $event_date = $_POST['event_date'] ?? '';
        $location = $_POST['location'] ?? '';

        error_log("Updating event: ID=$id, Name=$name, Description=$description, Date=$event_date, Location=$location");

        $event->update($id, $name, $description, $event_date, $location);
    } elseif (isset($_POST['delete'])) {
        $id = $_POST['id'] ?? 0;

        error_log("Deleting event: ID=$id");

        $event->delete($id);
    }
}

$events = $event->getAllByUser($session->get('user_id'));
require_once 'views/header.php';
?>

<h2>My Events</h2>

<form action="events.php" method="POST">
    <input type="hidden" name="id">
    <label for="name">Event Name:</label>
    <input type="text" id="name" name="name" required>
    <label for="description">Description:</label>
    <textarea id="description" name="description"></textarea>
    <label for="event_date">Date and Time:</label>
    <input type="datetime-local" id="event_date" name="event_date" required>
    <label for="location">Location:</label>
    <input type="text" id="location" name="location" required>
    <button type="submit" name="create">Create Event</button>
</form>

<h3>Existing Events</h3>
<ul>
    <?php foreach ($events as $event): ?>
        <li>
            <form action="events.php" method="POST">
                <input type="hidden" name="id" value="<?= $event['id'] ?>">
                <label for="name">Event Name:</label>
                <input type="text" name="name" value="<?= htmlspecialchars($event['name'] ?? '', ENT_QUOTES) ?>" required>
                <label for="description">Description:</label>
                <textarea name="description" required><?= htmlspecialchars($event['description'] ?? '', ENT_QUOTES) ?></textarea>
                <label for="event_date">Date and Time:</label>
                <input type="datetime-local" name="event_date" value="<?= date('Y-m-d\TH:i', strtotime($event['event_date'] ?? '')) ?>" required>
                <label for="location">Location:</label>
                <input type="text" name="location" value="<?= htmlspecialchars($event['location'] ?? '', ENT_QUOTES) ?>" required>
                <button type="submit" name="update">Update</button>
                <button type="submit" name="delete">Delete</button>
            </form>
        </li>
    <?php endforeach; ?>
</ul>

<?php require_once 'views/footer.php'; ?>
